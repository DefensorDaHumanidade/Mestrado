
#include "matriz-operacoesv3.h"

mymatriz *msomar(mymatriz *mat_a, mymatriz *mat_b, int tipo) {
   mymatriz *mat_soma;

    if (mat_a == NULL || mat_b == NULL) {
       printf("ERRO (MSOMAR) - Matriz A e/ou Matriz B invalida(s) - nula.\n");
       return NULL;
    }
   if (mat_a->lin != mat_b->lin || mat_a->col != mat_b->col) {
       printf("ERRO (MSOMAR) - Para somar a Matriz A e  a Matriz B precisam ter o mesmo numero de linhas e colunas.\n");
       return NULL;
    }
   mat_soma = (mymatriz*) malloc(sizeof(mymatriz));
   mat_soma->matriz = NULL;
   mat_soma->lin = mat_a->lin;
   mat_soma->col = mat_a->col;

   if (malocar(mat_soma)) {
		printf ("ERRO (MSOMAR) - Erro ao alocar matriz Soma\n");
        return NULL;
	}
	mzerar(mat_soma);

    if (tipo == 0) {    //IJ
        for (int i=0; i < mat_a->lin; i++) {
            for (int j=0; j < mat_a->col; j++){
                mat_soma->matriz[i][j] = mat_a->matriz[i][j] + mat_b->matriz[i][j];
            }
        }
    }
    else if (tipo == 1){    //JI
        for (int j=0; j < mat_a->col; j++){
            for (int i=0; i < mat_a->lin; i++) {
                mat_soma->matriz[i][j] = mat_a->matriz[i][j] + mat_b->matriz[i][j];
            }
        }
    }
    return mat_soma;
}

mymatriz *mmultiplicar(mymatriz *mat_a, mymatriz *mat_b, int tipo) {
    
    mymatriz *mat_mult;
  
    if (mat_a == NULL || mat_b == NULL) {
       printf("ERRO (MMULTIPLICAR) - Matriz A e/ou Matriz B invalida(s) - nula.\n");
       return NULL;
    }
     if (mat_a->col != mat_b->lin) {
       printf("ERRO (MMULTIPLICAR) - Para multiplicar o numero de linha da Matriz A e o numero de colunas da Matriz B devem ser iguais.\n");
       return NULL;
    }

    mat_mult = (mymatriz*) malloc(sizeof(mymatriz));
    mat_mult->matriz = NULL;
    mat_mult->lin = mat_a->lin;
    mat_mult->col = mat_b->col; 

    if (malocar(mat_mult)) {
		printf ("ERRO (MMULTIPLICAR) - Erro ao alocar matriz Multiplica\n");
        return NULL;
	}
	mzerar(mat_mult);

    if (tipo == 0) {    //IJK
        for(int i = 0; i < mat_a->lin; i++){          
            for(int j = 0; j < mat_b->col; j++){
                for(int k = 0; k < mat_a->col; k++){
                    mat_mult->matriz[i][j] += mat_a->matriz[i][k] * mat_b->matriz[k][j];
                }
            }
        }
    }
    else if (tipo == 1) {   //IKJ
        for(int i = 0; i < mat_a->lin; i++){
		    for(int k = 0; k < mat_a->col; k++){
			    for(int j = 0; j < mat_b->col; j++){
				    mat_mult->matriz[i][j] += mat_a->matriz[i][k] * mat_b->matriz[k][j];
			    }
		    }
	    }
    }
    else if (tipo == 2) {   //KIJ
        for(int k = 0; k < mat_a->col; k++){
            for(int i = 0; i < mat_a->lin; i++){
                for(int j = 0; j < mat_b->col; j++){
                     mat_mult->matriz[i][j] += mat_a->matriz[i][k] * mat_b->matriz[k][j];
                }
            }
        }
    }
    else if (tipo == 3) {   //KJI
        for(int k = 0; k < mat_a->col; k++){
            for(int j = 0; j < mat_b->col; j++){
                for(int i = 0; i < mat_a->lin; i++){
                    mat_mult->matriz[i][j] += mat_a->matriz[i][k] * mat_b->matriz[k][j];
                }
            }
        }
    }
    else if (tipo == 4) {   //JIK
        for(int j = 0; j < mat_b->col; j++){
		    for(int i = 0; i < mat_a->lin; i++){
			    for(int k = 0; k < mat_a->col; k++){
				    mat_mult->matriz[i][j] += mat_a->matriz[i][k] * mat_b->matriz[k][j];
                }
            }
        }
    }
    else if (tipo == 5) {   //JKI
        for(int j = 0; j < mat_b->col; j++){
            for(int k = 0; k < mat_a->col; k++){
                for(int i = 0; i < mat_a->lin; i++){
                    mat_mult->matriz[i][j] += mat_a->matriz[i][k] * mat_b->matriz[k][j];
                }
            }
        }
    }
    return mat_mult;
}