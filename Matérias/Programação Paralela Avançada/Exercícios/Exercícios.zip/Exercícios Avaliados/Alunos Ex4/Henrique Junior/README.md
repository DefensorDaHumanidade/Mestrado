###################################################
### Disciplina de Programação Paralela Avançada ###
###################################################
Revisão: ago/2019
Linguagem: C
Versão: v3 (tools, matriz, matriz-operacoes)
Executáveis: main, mainEx01, mainEx02, mainEx03a e mainEx04 e gmat

main: código principal de teste das funções
mainEx01: primeiro exercício - manipulação matrizes
mainEx02: segundo exercício - operações matrizes
mainEx03a: terceiro exercício - multiplicação em bloco
mainEx04: quarto exercício - multiplicação multithread
gmat: gerador de matrizes NxM em arquivo

ARQUIVOS:
 * README-res: resultado da execução de exemplo (./main mat_a3x4.example mat_b4x3.example);
 * mat_a3x4.example e mat_b4x3.example: matrizes exemplos A (3x4) e B(4x3);
 * toolsv3.(c/h): biblioteca de leitura/escrita de matrizes em arquivos;
 * matriz-operacoesv3.h: headers das funções de operações de matrizes que devem ser implementadas;
 * matriz-operacoesv3.c: operações de multiplicação e adição implementadas;
 * matriz-operacoes-threads.h: headers das multiplicações com threads
 * matriz-operacoes-threads.c: implementações das multiplicações com threads
 * matrizv3.h: headers das funções de gerência de matrizes que devem ser implementadas;
 * matrizv3.c: operações básicas de manipulação de matrizes;
 * gera_matrizv3.c: fontes do programa de geração de matrizes em arquivo;
 * main_matrizv3.c: fontes do programa de teste das operações de matrizes;

OBSERVAÇÕES
 * padrão adotado para retorno das funções: 1 para sucesso, 0 para erro.
 * execuções com erro são abortadas com exit(1) (padrão do C).

OBSERVAÇÕES PARA O EXERCÍCIO 2 - OPERAÇÕES ADIÇÃO E SUBTRAÇÃO
 * O executor das operações (mainEx02) foi ajustado para fazer adição e multiplicação
 das duas matrizes passadas por parâmetro (no fonte original somava a primeira matriz).
 * Foram comentadas as impressões de matrizes para não "poluir" tanto o terminal.

OBSERVAÇÕES PARA O EXERCÍCIO 4 - MULTIPLICAÇÃO MultiThread
 * É possível passar o número de threads desejadas para a multiplicação multithread,
 porém a multiplicação em bloco multithread utilizará sempre 2 threads.

PARA COMPILAR PROJETO
 $ make

PARA EXECUTAR
 $ ./mainEx04 mat_a3x4.example mat_b4x3.example

 ou

 $ ./mainEx04 mat_a3x4.example mat_b4x3.example 4

 (como explicado acima, a multiplicação em bloco sempre executará com 2 threads)
