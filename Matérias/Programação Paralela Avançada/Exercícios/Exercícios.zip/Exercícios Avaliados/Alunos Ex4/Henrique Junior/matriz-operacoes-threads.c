#include "matriz-operacoes-threads.h"

typedef struct {
      int tid;
      int ntasks;
      int i;
      int ilimit;
      mymatriz *mat_result, *mat_a, *mat_b;
} param_t;

typedef struct {
      int tid;
      int ntasks;
      matriz_bloco_t **v_submat_a,**v_submat_b,**v_submat_c;
} param_u;

void *exec_thread (void *arg) {
  param_t *p = (param_t *) arg;

  for(int i = p->i; i < p->ilimit; i++) { // N
    for(int k = 0; k < p->mat_a->col; k++) { // L
      for(int j = 0; j < p->mat_b->col; j++) { // M
        p->mat_result->matriz[i][j] += (p->mat_a->matriz[i][k] * p->mat_b->matriz[k][j]);
      }
    }
  }

  return NULL;
}

mymatriz *multiplicarTh(mymatriz *mat_a, mymatriz *mat_b, int ntasks) {

  param_t *args;
  pthread_t *threads;

  mymatriz *mat_result;

  mat_result = (mymatriz *) malloc(sizeof(mymatriz));

  threads = (pthread_t *) malloc(ntasks * sizeof(pthread_t));
  args = (param_t *) malloc(ntasks * sizeof(param_t));

  mat_result->lin = mat_a->lin; // N
  mat_result->col = mat_b->col; // M

  if (mat_a->col != mat_b->lin) {
    printf("ERRO: Matrizes inválidas para multiplicação.\n");
    exit(1);
  }

  if (!malocar(mat_result)) {
    printf ("ERROR: Out of memory\n");
    exit(1);
  }

  mzerar(mat_result);

  int pace = mat_a->lin / ntasks;
  int extra = mat_a->lin % ntasks;

  for (int i = 0; i < ntasks; i++)
  {
     args[i].tid = i;
     args[i].ntasks = ntasks;
     args[i].i = i * pace;
     args[i].ilimit = (i * pace) + pace;
     args[i].mat_result = mat_result;
     args[i].mat_a = mat_a;
     args[i].mat_b = mat_b;

     if(i == ntasks - 1) {
       args[i].ilimit+=extra;
     }

     pthread_create(&threads[i], NULL, exec_thread, (void *) (args+i));
  }

  for (int i = 0; i < ntasks; i++)
  {
     pthread_join(threads[i], NULL);
  }

  return mat_result;
}

void *exec_thread_blocos (void *arg) {
  param_u *p = (param_u *) arg;

  mmsubmatriz (p->v_submat_a[p->tid], p->v_submat_b[p->tid], p->v_submat_c[p->tid]);

  return NULL;
}

mymatriz *multiplicarThblocos(mymatriz *mat_a, mymatriz *mat_b, int ntasks) {

  matriz_bloco_t **v_submat_a,**v_submat_b,**v_submat_c;
  mymatriz *result;

  param_u *args;
  pthread_t *threads;

  args = (param_u *) malloc(ntasks * sizeof(param_u));
  threads = (pthread_t *) malloc(ntasks * sizeof(pthread_t));

  v_submat_a = particionar_matriz (mat_a->matriz, mat_a->lin, mat_a->col, 1, 2);
	v_submat_b = particionar_matriz (mat_b->matriz, mat_b->lin, mat_b->col, 0, 2);
	v_submat_c = csubmatrizv2 (mat_a->lin, mat_b->col, ntasks);

  args[0].tid = 0;
  args[0].ntasks = ntasks;
  args[0].v_submat_a = v_submat_a;
  args[0].v_submat_b = v_submat_b;
  args[0].v_submat_c = v_submat_c;

  pthread_create(&threads[0], NULL, exec_thread_blocos, (void *) (args+0));

  args[1].tid = 1;
  args[1].ntasks = ntasks;
  args[1].v_submat_a = v_submat_a;
  args[1].v_submat_b = v_submat_b;
  args[1].v_submat_c = v_submat_c;

  pthread_create(&threads[1], NULL, exec_thread_blocos, (void *) (args+1));

	pthread_join(threads[0], NULL);
  pthread_join(threads[1], NULL);

	result = msomar(v_submat_c[0]->matriz, v_submat_c[1]->matriz, 1);

  return result;
}
