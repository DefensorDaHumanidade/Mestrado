#include<stdio.h>

int can_execute_tests(int argc, char** argv);
int execute_tests();
