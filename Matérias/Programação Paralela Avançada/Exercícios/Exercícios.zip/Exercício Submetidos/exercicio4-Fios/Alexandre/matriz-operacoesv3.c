#include "matriz-operacoesv3.h"


mymatriz *msomar (mymatriz *mat_a, mymatriz *mat_b, int tipo){
    mymatriz *mat_resultado = malloc(sizeof(mymatriz));
    if((compararOrdem(mat_a,mat_b) == 1) || (compararOrdem(mat_a,mat_b) == 2)){ //Matriz é retangular OU é quadrada
        mat_resultado->matriz = NULL;
        mat_resultado->lin = mat_a->lin;
        mat_resultado->col = mat_a->col;
        if (malocar(mat_resultado)) {
            printf ("ERROR: Out of memory\n");
	    }
        if(tipo == 0){
            for(int i=0; i<mat_a->lin; i++){
                for(int j=0; j<mat_a->col; j++){
                    mat_resultado->matriz[i][j] = mat_a->matriz[i][j] + mat_b->matriz[i][j];
                }
            }
        }else{
            for(int j=0; j<mat_a->col; j++){
                for(int i=0; i<mat_a->lin; i++){
                    mat_resultado->matriz[i][j] = mat_a->matriz[i][j] + mat_b->matriz[i][j];
                }
            }
        }
        return (mat_resultado);
    }
    puts("Nao foi possivel realizar a operacao de soma, pois as matrizes de entrada nao eram compativeis");
    mat_resultado->matriz = NULL;
    mat_resultado->lin = 0;
    mat_resultado->col = 0;
    return mat_resultado;
}
mymatriz *mmultiplicar (mymatriz *mat_a, mymatriz *mat_b, int tipo){
    mymatriz *mat_resultado = malloc(sizeof(mymatriz));
    if((compararOrdem(mat_a,mat_b) == 2) || (compararOrdem(mat_a,mat_b) == 3)){ //Matriz é quadrada OU a quantidade de colunas de A é igual a quantidade de colunas de B
        mat_resultado->matriz = NULL;
        mat_resultado->lin = mat_a->lin;
        mat_resultado->col = mat_b->col;
        if (malocar(mat_resultado)) {
            printf ("ERROR: Out of memory\n");
	    }
        switch(tipo){
            case 1: ///ikj
                for(int i=0; i<mat_resultado->lin; ++i){
                    for(int k=0; k<mat_a->col; ++k){
                        for(int j=0; j<mat_resultado->col; ++j){                        
                            mat_resultado->matriz[i][j]+=mat_a->matriz[i][k]*mat_b->matriz[k][j];
                        }
                    }
                }
                break;
            case 2://kij
                for(int k=0; k<mat_a->col; ++k){
                    for(int i=0; i<mat_resultado->lin; ++i){
                        for(int j=0; j<mat_resultado->col; ++j){                        
                            mat_resultado->matriz[i][j]+=mat_a->matriz[i][k]*mat_b->matriz[k][j];
                        }
                    }
                }
                break;
            case 3://kji
                for(int k=0; k<mat_a->col; ++k){
                    for(int j=0; j<mat_resultado->col; ++j){ 
                        for(int i=0; i<mat_resultado->lin; ++i){                                               
                            mat_resultado->matriz[i][j]+=mat_a->matriz[i][k]*mat_b->matriz[k][j];
                        }
                    }
                }
                break;
            case 4://jki
                    for(int j=0; j<mat_resultado->col; ++j){
                        for(int k=0; k<mat_a->col; ++k){
                            for(int i=0; i<mat_resultado->lin; ++i){                                               
                                mat_resultado->matriz[i][j]+=mat_a->matriz[i][k]*mat_b->matriz[k][j];
                        }
                    }
                }
                break;
            case 5://jik
                    for(int j=0; j<mat_resultado->col; ++j){
                        for(int i=0; i<mat_resultado->lin; ++i){ 
                            for(int k=0; k<mat_a->col; ++k){                                                                          
                                mat_resultado->matriz[i][j]+=mat_a->matriz[i][k]*mat_b->matriz[k][j];
                        }
                    }
                }
                break;
            default:
                for(int i=0; i<mat_resultado->lin; ++i){
                    for(int j=0; j<mat_resultado->col; ++j){
                        for(int k=0; k<mat_a->col; ++k){
                            mat_resultado->matriz[i][j]+=mat_a->matriz[i][k]*mat_b->matriz[k][j];
                        }
                    }
                }

        }
        ///MULTIPLICAÇÃO COM 1 LAÇO
        /*
        for(int ijk=0; ijk<mat_resultado->lin*mat_resultado->col*mat_a->col; ++ijk){
            int i = ijk%mat_resultado->lin;
            int j = (ijk/mat_resultado->lin)%mat_resultado->col;
            int k = (ijk/mat_resultado->lin)%mat_a->col;
            mat_resultado->matriz[i][j]+=mat_a->matriz[i][k]*mat_b->matriz[k][j];
        }
        */
        ///MULTIPLICAÇÃO COM 2 LAÇOS
        /*
        for(int i=0; i<mat_resultado->lin; ++i){
            for(int jk=0; jk<mat_resultado->col*mat_a->col; ++jk){
                int j = jk%mat_resultado->col;
                int k = jk%mat_a->col;
                mat_resultado->matriz[i][j]+=mat_a->matriz[i][k]*mat_b->matriz[k][j];
            }
        }
        */
        ///MULTIPLICAÇÃO TRADICIONAL COM 3 LAÇOS
        /*
        for(int i=0; i<mat_resultado->lin; ++i){
            for(int j=0; j<mat_resultado->col; ++j){
                for(int k=0; k<mat_a->col; ++k){
                    mat_resultado->matriz[i][j]+=mat_a->matriz[i][k]*mat_b->matriz[k][j];
                }
            }
        }
        */
        return (mat_resultado);
    }
    puts("Nao foi possivel realizar a operacao de multiplicacao, pois as matrizes de entrada nao eram compativeis");
    mat_resultado->matriz = NULL;
    mat_resultado->lin = 0;
    mat_resultado->col = 0;
    return mat_resultado;
}



int mmsubmatriz (matriz_bloco_t *mat_suba, matriz_bloco_t *mat_subb, matriz_bloco_t *mat_subc){
    if (!mat_suba || !mat_subb || !mat_subc){
        printf("[mmsubmatriz] ERROR: Sem memória\n");
        return 1;
    }

    /*printf("AColuna: %d x %d\n", mat_suba->bloco->col_inicio, mat_suba->bloco->col_fim);
    printf("ALinha: %d x %d\n\n", mat_suba->bloco->lin_inicio, mat_suba->bloco->lin_fim);

    printf("BColuna: %d x %d\n", mat_subb->bloco->col_inicio, mat_subb->bloco->col_fim);
    printf("BLinha: %d x %d\n\n", mat_subb->bloco->lin_inicio, mat_subb->bloco->lin_fim);*/

    /*puts("Multiplicando essa: ");
    for(int i=mat_suba->bloco->lin_inicio; i<mat_suba->bloco->lin_fim; ++i){
        for(int j=mat_suba->bloco->col_inicio; j<mat_suba->bloco->col_fim; ++j){
            printf("%d\t", mat_suba->matriz->matriz[i][j]);
        }
        puts("");
    }
    
    puts("Por essa: ");
    for(int i=mat_subb->bloco->lin_inicio; i<mat_subb->bloco->lin_fim; ++i){
        for(int j=mat_subb->bloco->col_inicio; j<mat_subb->bloco->col_fim; ++j){
            printf("%d\t", mat_subb->matriz->matriz[i][j]);
        }
        puts("");
    }*/

    //puts("Imprimindo.....");
    for(int i=mat_subb->bloco->col_inicio; i<mat_subb->bloco->col_fim; i++){
        for(int j=mat_suba->bloco->lin_inicio; j<mat_suba->bloco->lin_fim; j++){
            for(int k=mat_subb->bloco->lin_inicio; k<mat_subb->bloco->lin_fim; k++ ){
                mat_subc->matriz->matriz[j][i] += mat_suba->matriz->matriz[j][k]*mat_subb->matriz->matriz[k][i];
            }
            //printf("%d\t", mat_subc->matriz->matriz[i][j]);
        }
        //puts("");
    }

    return 0;
}

matriz_bloco_t **csubmatrizv2 (int mat_lin, int mat_col, int divisor){

    matriz_bloco_t **resultado = NULL;
    resultado = (matriz_bloco_t **) calloc(divisor, sizeof(matriz_bloco_t *)); //tinha feito com malloc e o valgrind reclamou

    for(int i = 0; i< divisor; i++){
        resultado[i] = (matriz_bloco_t *) malloc(sizeof(matriz_bloco_t));
        resultado[i]->matriz = (mymatriz *) malloc(sizeof(mymatriz));
        resultado[i]->bloco = (bloco_t *) malloc(sizeof(bloco_t));
    }
    if (!resultado) {
        printf("[csubmatrizv2] ERROR: Sem memória\n");
        return NULL;
    }

    

    for (int i = 0; i < divisor; i++){
        mymatriz *auxiliar = (mymatriz *)malloc(sizeof(mymatriz));
        auxiliar->matriz = NULL;
        auxiliar->lin = mat_lin;
        auxiliar->col = mat_col;
        malocar(auxiliar);
        mzerar(auxiliar);
        resultado[i]->matriz = auxiliar;
        resultado[i]->bloco->lin_inicio = 0;
        resultado[i]->bloco->lin_fim = mat_lin;
        resultado[i]->bloco->col_inicio = 0;
        resultado[i]->bloco->col_fim = mat_col;
    }

    return resultado;
}

//PS, eu não aloco espaço para as particoes, ver o exercicio 2 e fazer usar AQUI a função malocar (mymatriz *matriz);
matriz_bloco_t **particionar_matriz (int **matriz, int mat_lin, int mat_col, int orientacao, int divisor){

    int porcaoSuperior = 0;
    int porcaoInferior = 0;
    int particaoAtual = 0;

    matriz_bloco_t **resultado = NULL;
    resultado = (matriz_bloco_t **) calloc(divisor, sizeof(matriz_bloco_t *)); //tinha feito com malloc e o valgrind reclamou
    for(int i = 0; i< divisor; i++){
        resultado[i] = (matriz_bloco_t *) malloc(sizeof(matriz_bloco_t));
        resultado[i]->matriz = (mymatriz *) malloc(sizeof(mymatriz));
        resultado[i]->bloco = (bloco_t *) malloc(sizeof(bloco_t));
    }

    if(orientacao == 0){  //corte horizontal
        /*if(mat_col % divisor == 0){
            printf("[colunas]As partições terão tamanhos iguais\n");
        }else{
            printf("[colunas]As particões terão tamanhos diferentes\n");
        }*/
        porcaoSuperior = (mat_lin + divisor -1)/divisor;
        do{
            resultado[particaoAtual]->matriz->matriz = matriz;
            resultado[particaoAtual]->matriz->lin = porcaoSuperior-porcaoInferior;
            resultado[particaoAtual]->matriz->col = mat_col;
            resultado[particaoAtual]->bloco->lin_inicio = porcaoInferior;
            resultado[particaoAtual]->bloco->lin_fim = porcaoSuperior;
            resultado[particaoAtual]->bloco->col_inicio = 0;
            resultado[particaoAtual]->bloco->col_fim = mat_col;
            //printf("SubMatriz[%d]: %d x %d\n", particaoAtual, resultado[particaoAtual]->bloco->lin_inicio, resultado[particaoAtual]->bloco->lin_fim);
            //printf("ColunaInicio [%d] - [%d] ColunaFim\n\n", resultado[particaoAtual]->bloco->col_inicio, resultado[particaoAtual]->bloco->col_fim);
            particaoAtual++;
            porcaoInferior = porcaoSuperior;
            porcaoSuperior = porcaoSuperior + porcaoSuperior;
            if(porcaoSuperior > mat_lin){
                porcaoSuperior = mat_lin;
            }
        }while(particaoAtual != divisor);
    }else{ //corte vertical
        /*if(mat_lin % divisor == 0){
            printf("[linhas]As partições terão tamanhos iguais\n");
        }else{
            printf("[linhas]As particões terão tamanhos diferentes\n");
        }*/
        porcaoSuperior = (mat_col + divisor -1)/divisor;
        do{
            resultado[particaoAtual]->matriz->matriz = matriz;
            resultado[particaoAtual]->matriz->lin = mat_lin;
            resultado[particaoAtual]->matriz->col = porcaoSuperior-porcaoInferior;
            resultado[particaoAtual]->bloco->lin_inicio = 0;
            resultado[particaoAtual]->bloco->lin_fim = mat_lin;
            resultado[particaoAtual]->bloco->col_inicio = porcaoInferior;
            resultado[particaoAtual]->bloco->col_fim = porcaoSuperior;
            //printf("SubMatriz[%d]: %d x %d\n", particaoAtual, resultado[particaoAtual]->bloco->lin_inicio, resultado[particaoAtual]->bloco->lin_fim);
            //printf("ColunaInicio [%d] - [%d] ColunaFim\n\n", resultado[particaoAtual]->bloco->col_inicio, resultado[particaoAtual]->bloco->col_fim);
            particaoAtual++;
            porcaoInferior = porcaoSuperior;
            porcaoSuperior = porcaoSuperior + porcaoSuperior;
            if(porcaoSuperior > mat_col){
                porcaoSuperior = mat_col;
            }
        }while(particaoAtual != divisor);
    }



/*FORMA ANTIGA COMO EU ESTAVA TENTANDO RESOLVER
    if(orientacao == 1){  //corte horizontal
        if(mat_col % divisor == 0){
            printf("[colunas]As partições terão tamanhos iguais\n");
        }else{
            printf("[colunas]As particões terão tamanhos diferentes\n");
        }
        porcaoSuperior = (mat_lin + divisor -1)/divisor;
        do{
            //printf("resultadoHor[%d]\n", particaoAtual);
            for(int i = porcaoInferior; i<porcaoSuperior; i++){
                for(int j=0; j<mat_col; j++){
                    printf("|%d|\t", matriz[i][j]);
                    //resultado[particaoAtual]->matriz->matriz[i-porcaoInferior][j] = matriz[i][j];
                }
                puts("");
            }
            resultado[particaoAtual]->matriz->lin = porcaoSuperior-porcaoInferior;
            resultado[particaoAtual]->matriz->col = mat_col;
            printf("%d x %d\n\n", resultado[particaoAtual]->matriz->lin, resultado[particaoAtual]->matriz->col);
            particaoAtual++;
            porcaoInferior = porcaoSuperior;
            porcaoSuperior = porcaoSuperior + porcaoSuperior;
            if(porcaoSuperior > mat_lin){
                porcaoSuperior = mat_lin;
            }
        }while(particaoAtual != divisor);
    }else{ //corte vertical
        if(mat_lin % divisor == 0){
            printf("[linhas]As partições terão tamanhos iguais\n");
        }else{
            printf("[linhas]As particões terão tamanhos diferentes\n");
        }
                porcaoSuperior = (mat_col + divisor -1)/divisor;
        do{
            //printf("resultadoVer[%d]\n", particaoAtual);
            for(int j=porcaoInferior; j<porcaoSuperior; j++){
                for(int i = 0; i<mat_lin; i++){                
                    printf("|%d|\t", matriz[i][j]);
                    //resultado[particaoAtual]->matriz->matriz[i][j-porcaoInferior] = matriz[i][j];
                }
                puts("");
            }
            resultado[particaoAtual]->matriz->lin = mat_lin;
            resultado[particaoAtual]->matriz->col = porcaoSuperior-porcaoInferior;
            printf("%d x %d\n\n", resultado[particaoAtual]->matriz->lin, resultado[particaoAtual]->matriz->col);
            particaoAtual++;
            porcaoInferior = porcaoSuperior;
            porcaoSuperior = porcaoSuperior + porcaoSuperior;
            if(porcaoSuperior > mat_col){
                porcaoSuperior = mat_col;
            }
        }while(particaoAtual != divisor);
    }
*/

/*
    printf("\nINICIO\n");
    for(int i =0; i<mat_lin; i++){
        for(int j=0; j<mat_col; j++){
            printf("|%d|\t", matriz[i][j]);
        }
        puts("");
    }
    printf("\nFIM\n");*/
    return resultado;
}