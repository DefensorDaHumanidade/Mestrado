#include "matriz-operacoes-thread.h"
#include <pthread.h>
#include <stdlib.h>
#include <string.h>
#include "matrizv3.h"
#include "matriz-operacoesv3.h"

mymatriz *multiplicarTh(mymatriz *matrixA, mymatriz *matrixB, int id) {
    mult_normal_package mult_content[id];
    pthread_t threads[id];
    mymatriz *resultado = (mymatriz *) malloc(sizeof(mymatriz));

    resultado->lin = matrixA->lin;
    resultado->col = matrixB->col;
    malocar(resultado);
    mzerar(resultado);
    int i;

    for (i = 0; i < id; ++i) {
        mult_content[i].matriz_a = matrixA;
        mult_content[i].matriz_b = matrixB;
        mult_content[i].linha = i;
        mult_content[i].threads = id;
        mult_content[i].resultado = resultado;

        pthread_create(&threads[i], NULL, mult_normal_job, (void *) (mult_content + i));
    }

    for (i = 0; i < id; ++i) {
        pthread_join(threads[i], NULL);
    }

    return resultado;
}

void *mult_block_thread_job(void *dado) {
    mult_block_normal_package *matriz = (mult_block_normal_package *) dado;
    mmsubmatriz(matriz->inicio, matriz->fim, matriz->resultado);
    return NULL;
}

void *mult_normal_job(void *dado) {
    mult_normal_package *data = (mult_normal_package *) dado;
    for (int i = data->linha; i < data->matriz_a->lin; i += data->threads) {
        for (int j = 0; j < data->matriz_b->col; j++) {
            for (int k = 0; k < data->matriz_a->col; ++k) {
                data->resultado->matriz[i][j] += data->matriz_a->matriz[i][k] * data->matriz_b->matriz[k][j];
            }
        }
    }
    return NULL;
}




mymatriz *multiplicarThblocos(mymatriz *matrixA, mymatriz *matrixB, int id) {
    matriz_bloco_t **Vsubmat_a = NULL, **Vsubmat_b = NULL, **Vsubmat_c = NULL;

    mult_block_normal_package packages[id];
    pthread_t threads[id];

    Vsubmat_a = particionar_matriz(matrixA->matriz, matrixA->lin, matrixA->col, 1, id);
    Vsubmat_b = particionar_matriz(matrixB->matriz, matrixB->lin, matrixB->col, 0, id);

    Vsubmat_c = csubmatrizv2(matrixA->lin, matrixB->col, id);

    mymatriz *resultado = (mymatriz *) malloc(sizeof(mymatriz));

    resultado->lin = matrixA->lin;
    resultado->col = matrixB->col;

    malocar(resultado);
    mzerar(resultado);

    for (int i = 0; i < id; i++) {
        packages[i].inicio = Vsubmat_a[i];
        packages[i].fim = Vsubmat_b[i];
        packages[i].resultado = Vsubmat_c[i];

        pthread_create(&threads[i], NULL, mult_block_thread_job, (void *) (packages + i));
    }

    for (int i = 0; i < id; i++) {
        pthread_join(threads[i], NULL);
        mymatriz *temp = msomar(resultado, Vsubmat_c[i]->matriz, 0);
        resultado = temp;
    }

    return resultado;
}

