#include "matrizv3.h"

typedef struct {
    mymatriz* matriz_a, *matriz_b, *resultado;
    int linha, threads;
} mult_normal_package;

typedef struct {
    matriz_bloco_t *inicio;
    matriz_bloco_t *fim;
    matriz_bloco_t *resultado;
} mult_block_normal_package;

mymatriz* multiplicarTh(mymatriz*, mymatriz*, int);
void* mult_normal_job(void*);

mymatriz* multiplicarThblocos(mymatriz*, mymatriz*, int);
void* mult_block_thread_job(void*);
