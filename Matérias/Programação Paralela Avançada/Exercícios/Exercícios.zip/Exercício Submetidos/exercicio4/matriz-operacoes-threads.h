#include <stdio.h>
#include <stdlib.h>
#include <string.h>
#include <assert.h>
#include "matrizv3.h"


void *multiplicarTh (void *arg){
    mymatriz *p = (mymatriz *) arg;
    printf("eu entreei e deu boas:    %d\n\n\n\n", p[0][0]);
    return NULL;
}

mymatriz *multiplicarThBlocos (mymatriz *mat_a, mymatriz *mat_b, int tipo){
    return mat_a;
}

/*
void *oi(void *i){
	puts("UEUEUEUEUEUEUEUUEUEUE");
	printf("HAHA------------------------------------------------------------------------------------AAAAAAAAAA %d\n\n", i);
	puts("FIMIFMIFMIFMIF");
}*/

