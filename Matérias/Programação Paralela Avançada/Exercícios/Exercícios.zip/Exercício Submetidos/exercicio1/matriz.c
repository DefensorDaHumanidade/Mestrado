#include "matriz.h"

int malocar (mymatriz *matriz){
    #ifdef DEBUG
    printf("[malocar]\t Atribuindo os valores definidos no programa principal aos valores da estrutura da matriz [lin][col]\n");
    #endif
    matriz->lin = N;
    matriz->col = M;
    #ifdef DEBUG
    printf("[malocar]\t Valores [lin] e [col] atribuidos com sucesso!!!\n");
    #endif
    #ifdef DEBUG
    printf("[malocar]\t Alocando Espaco para uma Matriz[%d][%d]\n", matriz->lin, matriz->col);
    #endif
    #ifdef DEBUG
    printf("[malocar]\t Alocando [%d] linhas\n", matriz->lin);
    #endif
    matriz->matriz = malloc (matriz->lin * sizeof (int *));
    for (int i=0; i<matriz->lin; i++){
        #ifdef DEBUG
        printf("[malocar]\t Alocando coluna[%d]\n", i);
        #endif
        matriz->matriz[i] = malloc (matriz->col * sizeof (int));
        for (int j=0; j<matriz->col; j++){
            matriz->matriz[i][j] = 0;       //PARA NÃO DAR ERRO NO VALGRIND É NECESSÁRIO QUE A VARIÁVEL SEMPRE SEJA INICIALIZADA
        }
    }
    #ifdef DEBUG
    printf("[malocar]\t Matriz[%d][%d] alocada com sucesso!!!\n\n", matriz->lin, matriz->col);
    #endif
    return 1;
}

int mimprimir (mymatriz *matriz){
    #ifdef DEBUG
    printf("[mimprimir]\t Imprimindo Matriz[%d][%d]:\n", matriz->lin, matriz->col);
    #endif
    for(int i=0; i<matriz->lin; i++){
        for(int j=0; j<matriz->col; j++){
            printf("[%d]\t", matriz->matriz[i][j]);
        }
    puts("");
    }
    #ifdef DEBUG
    printf("[mimprimir]\t Matriz[%d][%d] impressa com sucesso!!!\n\n", matriz->lin, matriz->col);
    #endif
    return 1;
}

int mzerar (mymatriz *matriz){
    #ifdef DEBUG
    printf("[mzerar]\t Zerando os elementos da Matriz[%d][%d]:\n", matriz->lin, matriz->col);
    #endif
    for(int i=0; i<matriz->lin; i++){
        for(int j=0; j<matriz->col; j++){
            matriz->matriz[i][j] = 0;
        }
    }
    #ifdef DEBUG
    printf("[mzerar]\t Matriz[%d][%d] zerada com sucesso!!!\n\n", matriz->lin, matriz->col);
    #endif
    return 1;
}

int mgerar (mymatriz *matriz, int valor){
    #ifdef DEBUG
    printf("[mgerar]\t Gerar elementos para a Matriz[%d][%d]\n", matriz->lin, matriz->col);
    #endif
    if(valor == -9999){
        #ifdef DEBUG
        printf("[mgerar]\t Gerando elementos aleatorios\n");
        #endif
        for(int i=0; i<matriz->lin; i++){
            for(int j=0; j<matriz->col; j++){
                matriz->matriz[i][j] = rand()%100;
            }
        }
        #ifdef DEBUG
        printf("[mgerar]\t Matriz[%d][%d] aleatoria gerada com sucesso!!!\n\n", matriz->lin, matriz->col);
        #endif
    }else{
        #ifdef DEBUG
        printf("[mgerar]\t Preenchendo a Matriz[%d][%d] com %d\n", matriz->lin, matriz->col, valor);
        #endif
        for(int i = 0; i<matriz->lin; i++){
            for(int j = 0; j<matriz->col; j++){
                matriz->matriz[i][j] = valor;
            }
        }
        #ifdef DEBUG
        printf("[mgerar]\t Matriz[%d][%d] com %d preenchida com sucesso!!!\n\n", matriz->lin, matriz->col, valor);
        #endif
    }
    return 1;
}

int mliberar (mymatriz *matriz){
    #ifdef DEBUG
    printf("[mliberar]\t Liberando a Matriz[%d][%d]\n", matriz->lin, matriz->col);
    #endif
    for (int i=0; i<matriz->lin; i++)
        free(matriz->matriz[i]);
    free(matriz->matriz);
    //free(&matriz->lin);
    //free(&matriz->col);
    //free(matriz);
    #ifdef DEBUG
    printf("[mliberar]\t Matriz[%d][%d] liberada com sucesso!!!\n\n", matriz->lin, matriz->col);
    #endif
    return 1;
}


int mcomparar (mymatriz *matriza, mymatriz *matrizb){
    #ifdef DEBUG
    printf("[mcomparar]\t Comparando a Matriz[%d][%d] com a Matriz[%d][%d]\n", matriza->lin, matriza->col, matrizb->lin, matrizb->col);
    #endif
    #ifdef DEBUG
    printf("[mcomparar]\t Comparando linhas*colunas\n");
    #endif
    if(matriza->lin*matriza->col != matrizb->lin*matrizb->col){
        puts("Matrizes diferentes: Quantidade de elementos nao e a mesma!");
        printf("Matriz A tem %d elementos.\n", matriza->lin*matriza->col);
        printf("Matriz B tem %d elementos\n", matrizb->lin*matrizb->col);
        return 0;
    }
    #ifdef DEBUG
    printf("[mcomparar]\t Comparando linhas\n");
    #endif
    if(matriza->lin != matrizb->lin){
        puts("Matrizes diferentes: Quantidade de linhas nao e a mesma!");
        printf("Matriz A tem %d elementos.\n", matriza->lin);
        printf("Matriz B tem %d elementos\n", matrizb->lin);
        return 0;
    }
    #ifdef DEBUG
    printf("[mcomparar]\t Comparando colunas\n");
    #endif
    if(matriza->col != matrizb->col){
        puts("Matrizes diferentes: Quantidade de colunas nao e a mesma!");
        printf("Matriz A tem %d elementos.\n", matriza->col);
        printf("Matriz B tem %d elementos\n", matrizb->col);
        return 0;
    }
    #ifdef DEBUG
    printf("[mcomparar]\t Comparando elemento por elemento\n");
    #endif
    for(int i = 0; i<matriza->lin; i++){
        for(int j = 0; j<matriza->col; j++){
            if(matriza->matriz[i][j] != matrizb->matriz[i][j]){
                puts("Matrizes diferentes: Os elementos nao sao iguais!");
                printf("Primeira Matriz[%d][%d] = %d\n", i, j, matriza->matriz[i][j]);
                printf("Segunda Matriz[%d][%d] = %d\n", i, j, matrizb->matriz[i][j]);
                return 0;
            }
        }
    }
    puts("As matriz sao identicas!!!");
    #ifdef DEBUG
    printf("[mcomparar]\t Fim da comparacao!!!\n\n");
    #endif
    return 1;
}