#ifndef MATRIZ_H   // guardas de cabeçalho, impedem inclusões cíclicas
#define MATRIZ_H
#ifdef DEBUG
#endif

typedef struct {
    int **matriz;
    int lin;
    int col;
} mymatriz;

int mzerar (mymatriz *matriz);
int mliberar (mymatriz *matriz);
int malocar (mymatriz *matriz);
int mimprimir (mymatriz *matriz);

int mgerar (mymatriz *matriz, int valor);
int mcomparar (mymatriz *matriza, mymatriz *matrizb);

#endif