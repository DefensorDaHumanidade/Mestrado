#include "matriz-operacoesv3.h"

mymatriz *msomar (mymatriz *mat_a, mymatriz *mat_b, int tipo){
    if(compararOrdem(mat_a,mat_b) == 1){
        mymatriz *mat_resultado = malloc(sizeof(mymatriz));
        mat_resultado->matriz = NULL;
        mat_resultado->lin = mat_a->lin;
        mat_resultado->col = mat_a->col;
        if (malocar(mat_resultado)) {
            printf ("ERROR: Out of memory\n");
	    }
        if(tipo == 0){
            for(int i=0; i<mat_a->lin; i++){
                for(int j=0; j<mat_a->col; j++){
                    mat_resultado->matriz[i][j] = mat_a->matriz[i][j] + mat_b->matriz[i][j];
                }
            }
        }else{
            for(int j=0; j<mat_a->col; j++){
                for(int i=0; i<mat_a->lin; i++){
                    mat_resultado->matriz[i][j] = mat_a->matriz[i][j] + mat_b->matriz[i][j];
                }
            }
        }
        return (mat_resultado);
    }
    puts("Nao foi possivel realizar a operacao de soma, pois as matrizes de entrada nao eram compativeis");
    return mat_a;
}
mymatriz *mmultiplicar (mymatriz *mat_a, mymatriz *mat_b, int tipo){
    if(compararOrdem(mat_a,mat_b) >= 1){
        mymatriz *mat_resultado = malloc(sizeof(mymatriz));
        mat_resultado->matriz = NULL;
        mat_resultado->lin = mat_a->lin;
        mat_resultado->col = mat_b->col;
        if (malocar(mat_resultado)) {
            printf ("ERROR: Out of memory\n");
	    }
        switch(tipo){
            case 1: ///ikj
                for(int i=0; i<mat_resultado->lin; ++i){
                    for(int k=0; k<mat_a->col; ++k){
                        for(int j=0; j<mat_resultado->col; ++j){                        
                            mat_resultado->matriz[i][j]+=mat_a->matriz[i][k]*mat_b->matriz[k][j];
                        }
                    }
                }
                break;
            case 2://kij
                for(int k=0; k<mat_a->col; ++k){
                    for(int i=0; i<mat_resultado->lin; ++i){
                        for(int j=0; j<mat_resultado->col; ++j){                        
                            mat_resultado->matriz[i][j]+=mat_a->matriz[i][k]*mat_b->matriz[k][j];
                        }
                    }
                }
                break;
            case 3://kji
                for(int k=0; k<mat_a->col; ++k){
                    for(int j=0; j<mat_resultado->col; ++j){ 
                        for(int i=0; i<mat_resultado->lin; ++i){                                               
                            mat_resultado->matriz[i][j]+=mat_a->matriz[i][k]*mat_b->matriz[k][j];
                        }
                    }
                }
                break;
            case 4://jki
                    for(int j=0; j<mat_resultado->col; ++j){
                        for(int k=0; k<mat_a->col; ++k){
                            for(int i=0; i<mat_resultado->lin; ++i){                                               
                                mat_resultado->matriz[i][j]+=mat_a->matriz[i][k]*mat_b->matriz[k][j];
                        }
                    }
                }
                break;
            case 5://jik
                    for(int j=0; j<mat_resultado->col; ++j){
                        for(int i=0; i<mat_resultado->lin; ++i){ 
                            for(int k=0; k<mat_a->col; ++k){                                                                          
                                mat_resultado->matriz[i][j]+=mat_a->matriz[i][k]*mat_b->matriz[k][j];
                        }
                    }
                }
                break;
            default:
                for(int i=0; i<mat_resultado->lin; ++i){
                    for(int j=0; j<mat_resultado->col; ++j){
                        for(int k=0; k<mat_a->col; ++k){
                            mat_resultado->matriz[i][j]+=mat_a->matriz[i][k]*mat_b->matriz[k][j];
                        }
                    }
                }

        }
        ///MULTIPLICAÇÃO COM 1 LAÇO
        /*
        for(int ijk=0; ijk<mat_resultado->lin*mat_resultado->col*mat_a->col; ++ijk){
            int i = ijk%mat_resultado->lin;
            int j = (ijk/mat_resultado->lin)%mat_resultado->col;
            int k = (ijk/mat_resultado->lin)%mat_a->col;
            mat_resultado->matriz[i][j]+=mat_a->matriz[i][k]*mat_b->matriz[k][j];
        }
        */
        ///MULTIPLICAÇÃO COM 2 LAÇOS
        /*
        for(int i=0; i<mat_resultado->lin; ++i){
            for(int jk=0; jk<mat_resultado->col*mat_a->col; ++jk){
                int j = jk%mat_resultado->col;
                int k = jk%mat_a->col;
                mat_resultado->matriz[i][j]+=mat_a->matriz[i][k]*mat_b->matriz[k][j];
            }
        }
        */
        ///MULTIPLICAÇÃO TRADICIONAL COM 3 LAÇOS
        /*
        for(int i=0; i<mat_resultado->lin; ++i){
            for(int j=0; j<mat_resultado->col; ++j){
                for(int k=0; k<mat_a->col; ++k){
                    mat_resultado->matriz[i][j]+=mat_a->matriz[i][k]*mat_b->matriz[k][j];
                }
            }
        }
        */

        return (mat_resultado);
    }
    puts("Nao foi possivel realizar a operacao de multiplicacao, pois as matrizes de entrada nao eram compativeis");
    return mat_a;
}