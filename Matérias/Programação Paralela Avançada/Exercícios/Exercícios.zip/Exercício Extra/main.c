#include <stdio.h>
#include <mpi.h>
#include <stdlib.h>
#include <string.h>

#define LIMITE 30

int contador=0;
int dimensao = 0;
int rank, size;


int historico_I[LIMITE];
int historico_J[LIMITE];

//char todas_solucoes[9999];

int todas = 0;

char texto[99999999];

char aux[5];


int MarcarDiagonais(int linha, int coluna, int tabuleiro[dimensao][dimensao][2]){
    int i, j, k;
    int diagonal = 0;
    for(i=0; i<dimensao; i++){
        for(j=0; j<dimensao; j++){
            diagonal = 0;
            for(k=0; k<dimensao; k++){
                if( (linha != i+k || coluna != j+k) && (linha != i-k || coluna != j+k) && (linha != i+k || coluna != j-k) && (linha != i-k || coluna != j-k) && (tabuleiro[i][j][1] == 0)){

                }else{
                    diagonal++;
                }
            }
            if(diagonal != 0 ){
                tabuleiro[i][j][1] = tabuleiro[i][j][1] - 1;
            }
        }
    }
    return 0;
}

int MarcarLinhasColunas(int linha, int coluna, int tabuleiro[dimensao][dimensao][2]){
    int i, j, k;
    for(i=0; i<dimensao; i++){
        for(j=0; j<dimensao; j++){
            if((i != linha && j != coluna) && (tabuleiro[i][j][1] == 0)){
                //printf(" %d\t ", tabuleiro[i][j][0]);
            }else{
                tabuleiro[i][j][1] =tabuleiro[i][j][1] -1;
                //printf(" X\t "); 
            }
        }
    }
}

int DesmarcarDiagonais(int linha, int coluna, int tabuleiro[dimensao][dimensao][2]){
    int diagonal =0;
    int i, j, k;
    for(i=0; i<dimensao; i++){
        for(j=0; j<dimensao; j++){
            diagonal =0;
            for(k=0; k<dimensao; k++){
                if( (linha != i+k || coluna != j+k) && (linha != i-k || coluna != j+k) && (linha != i+k || coluna != j-k) && (linha != i-k || coluna != j-k) && (tabuleiro[i][j][1] == 0)){

                }else{
                    diagonal++;
                }
            }
            if(diagonal != 0 ){
                tabuleiro[i][j][1] = tabuleiro[i][j][1]+1;
            }
        }
    }
    return 0;
}

int DesmarcarLinhasColunas(int linha, int coluna, int tabuleiro[dimensao][dimensao][2]){
    int i, j, k;
    for(i=0; i<dimensao; i++){
        for(j=0; j<dimensao; j++){
            if((i != linha && j != coluna) && (tabuleiro[i][j][1] == 0)){
                //printf(" %d, %d\t ", i, j);
            }else{
                tabuleiro[i][j][1] =tabuleiro[i][j][1]+1;
                //printf(" X, X\t ");
            }
        }
    }
}


int respostas(int linha, int coluna, int tabuleiro[dimensao][dimensao][2]){
    int i, j, k;
    int solucoes[dimensao];
    MarcarDiagonais(linha, coluna, tabuleiro);
    MarcarLinhasColunas(linha, coluna, tabuleiro);
   
    historico_I[contador] = linha;
    historico_J[contador] = coluna;
    contador++;


    if(contador == dimensao){
        for(k=0; k<dimensao; k++){
            ////////////////////////////////printf("%d;", tabuleiro[historico_I[k]][historico_J[k]][0] );
            //sprintf(&texto[todas], "%d", tabuleiro[historico_I[k]][historico_J[k]][0]);
            sprintf(aux, "%d", tabuleiro[historico_I[k]][historico_J[k]][0]);
            //solucoes[k] =tabuleiro[historico_I[k]][historico_J[k]][0];
            //fprintf(arquivo, "%d;", tabuleiro[historico_I[k]][historico_J[k]][0]);
            
            strcat(texto, aux);
            strcat(texto, ";");
            /*todas++;
            texto[todas] =  ';';*/
            todas++;
            
        }
        //MPI_Gather(&solucoes, dimensao, MPI_INT, todas_solucoes, dimensao, MPI_INT, 0, MPI_COMM_WORLD);
        /*texto[todas] = '\n';
        puts("");
        todas++;*/
        ////////////////////////////////printf("[%s]", &texto[0]);
        strcat(texto, "\n");
        //fprintf(arquivo, "\n");
    }
    
    
    for(i=linha; i<dimensao; i++){
        for(j=0; j<dimensao; j++){
            if((tabuleiro[i][j][1] == 0)){
                if( (i - linha) == 1){
                    respostas(i, j, tabuleiro);
                }else{
                    return 0;
                }                
                DesmarcarDiagonais(linha, coluna, tabuleiro);
                DesmarcarLinhasColunas(linha, coluna, tabuleiro);
                contador--;
            }
        }
    }

}



int main(int argc, char **argv) {
    

    int i, j, k;
    int contador2=0;
    
    

    dimensao = atoi(argv[1]);


    int tabuleiro[dimensao][dimensao][2];

    for(i=0; i<dimensao; i++){
        for(j=0; j<dimensao; j++){
            tabuleiro[i][j][0] = contador2;
            tabuleiro[i][j][1] = 0;
            contador2++;
        }
    }



    MPI_Init(&argc, &argv);
	MPI_Comm_rank(MPI_COMM_WORLD, &rank);
	/////////MPI_Comm_size(MPI_COMM_WORLD, &size);


    MPI_File   arquivo;
    MPI_Status status;
    ///////MPI_Datatype localarray;

    /*char nome[20];
    snprintf(nome, 20, "Arquivo%d", rank); 
    strcat(nome, ".txt");*/



    MPI_File_open(MPI_COMM_WORLD, "BDados2.txt", MPI_MODE_CREATE|MPI_MODE_WRONLY, MPI_INFO_NULL, &arquivo);

    //MPI_File_set_view(arquivo, 0,  MPI_CHAR, MPI_CHAR, "native", MPI_INFO_NULL);


    contador = 0;
    respostas(0, rank, tabuleiro);    
    MPI_File_write_ordered(arquivo, texto, strlen(texto), MPI_CHAR, &status);



/*
if(rank == 1){
    //MPI_File_write( arquivo, texto, strlen(texto), MPI_CHAR, &status );
    printf("%s", &texto[0]);

}
puts("");
MPI_Barrier(MPI_COMM_WORLD);*/

//IGNORAR BAIXO
/*if(rank != 0){
    MPI_File_write( arquivo, texto, todas, MPI_CHAR, &status );
    MPI_Barrier(MPI_COMM_WORLD);
}else{
    MPI_Barrier(MPI_COMM_WORLD);
    MPI_File_write( arquivo, texto, todas, MPI_CHAR, &status );
}*/
//MPI_File_write( arquivo, texto, todas, MPI_CHAR, &status );

//MPI_File_write_at_all(arquivo, rank * dimensao, texto, todas, MPI_CHAR, MPI_STATUS_IGNORE);
//IGNORAR CIMA
    
    
    MPI_File_close(&arquivo);






///IGNORAR--- BAIXO

    //if(solucoes[0] == solucoes[1]){
        
    /*}else{
        MPI_Gather(NULL, 0, MPI_INT, todas_solucoes, dimensao, MPI_INT, 0, MPI_COMM_WORLD);
    }*/
    //MPI_Gather(&texto, 200, MPI_CHAR, todas_solucoes, 200, MPI_CHAR, 0, MPI_COMM_WORLD);

 
/*
    if(rank == 0){
        printf("**********************************************\n");
		//printf("(%d) – Recebi vetor: ", rank);
		for(i=0; i<200; i++){
            //if(todas_solucoes[i] != todas_solucoes[i+1]){
                printf("%c", todas_solucoes[i]);
            //}
		}
	}*/

    ///IGNORAR--- CIMA


    MPI_Finalize();
    return 0;
}