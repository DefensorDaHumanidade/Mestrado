#include <mpi.h>
#include <stdio.h>
#include <stdlib.h>
#define MAXN 31




int count = 0;
int respostas = 0;

void solve(int n, int col, int *hist, int inicio){
	int casa_tabuleiro = 0;
	if (col == n) {
		//printf("\nNo. %d\n-----\n", ++count);
		for (int i = 0; i < n; i++){
			for (int j = 0; j < n; j++){
				//putchar(j == hist[i] ? 'Q' : ((i + j) & 1) ? ' ' : '.');
				if(j == hist[i]){
					if(respostas == 0 && casa_tabuleiro != inicio){
						return;
					}
					printf("%d;", casa_tabuleiro);
					respostas++;
					if(respostas == n){
						puts("");
						respostas=0;
					}
				}
				casa_tabuleiro++;
			}
		}
		//return;
	}

	#define attack(i, j) (hist[j] == i || abs(hist[j] - i) == col - j)
	
	for (int i = 0, j = 0; i < n; i++) {
		for (j = 0; j < col && !attack(i, j); j++);
		if (j < col) continue;
 
		hist[col] = i;
		solve(n, col + 1, hist, inicio);
	}
}



int main(int argc, char **argv) {
	int solucoes[5000], *todas_solucoes;
	int rank, size, i;
	
	int n = atoi(argv[1]);
	int hist[n];

	if (argc != 2){
		printf ("ERRO: Numero de parametros %s <dimensao_tabuleiro>\n", argv[0]);
		exit(1);
	}

	int tabuleiro;	
	tabuleiro = atoi(argv[1]);
	todas_solucoes = (int *)malloc(2*size*sizeof(MPI_INT));
	

	MPI_Init(&argc, &argv);
	MPI_Comm_rank(MPI_COMM_WORLD, &rank);
	MPI_Comm_size(MPI_COMM_WORLD, &size);


	


	
	solucoes[0] = rank;
	solucoes[1] = rank*rank;
	//printf ("(%d) - Generated %d, %d \n",rank, solucoes[0], solucoes[1]);

	MPI_Gather(&solucoes, 2, MPI_INT, todas_solucoes, 2, MPI_INT, 0, MPI_COMM_WORLD);

	solve(n, 0, hist, rank);


	if(rank == 0) {
		//printf("(%d) – Recebi vetor: ", rank);
		for(i=0; i<2*size; i++){
			//printf("%d;", todas_solucoes[i]);
			if(i%2 == 1){
				//printf("\n");
			}
		}
	}
	MPI_Finalize();

int j, k, l;

	
	if(rank == 0){
		puts("****************************");
		int contador=0;
		int x=0;
		int matriz[tabuleiro][tabuleiro];
		for(i=0; i<tabuleiro; i++){
			for(j=0; j<tabuleiro; j++){
				matriz[i][j] = contador++;
			}
		}


	//solve(n, 0, hist, 4);



	/* só funciona para um 4x4
		for(i=0; i<tabuleiro; i++){ //##########################################
			for(j=tabuleiro; j<2*tabuleiro; j++){//##########################################
				if( (j-i-1 == tabuleiro*1) || (j-i+1 == tabuleiro*1) ){ //EXCLUINDO DIAGONAL IXJ
					goto fim;
				}
				for(k=2*tabuleiro; k<3*tabuleiro; k++){//##########################################
					if( (k-i-2 == tabuleiro*2) || (k-i+2 == tabuleiro*2) ){ //EXCLUINDO DIAGONAL IXJ
						goto fim;
					}
					if( (k-j-1 == tabuleiro*1) || (k-j+1 == tabuleiro*1) ){ //EXCLUINDO DIAGONAL JXK
						goto fim;
					}
					for(l=3*tabuleiro; l<4*tabuleiro; l++){//##########################################
						if( (l-i-3 == tabuleiro*3) || (l-i+3 == tabuleiro*3) ){	//EXCLUINDO DIAGONAL IXL
							goto fim;
						}
						if( (l-j-2 == tabuleiro*2) || (l-j+2 == tabuleiro*2) ){ //EXCLUINDO DIAGONAL JXL
							goto fim;
						}
						if( (l-k-1 == tabuleiro*1) || (l-k+1 == tabuleiro*1) ){ //EXCLUINDO DIAGONAL KXL
							goto fim;
						}
						//***************
						if(l-k == tabuleiro*1){ //EXCLUINDO AS COLUNAS KXL
							goto fim;
						}
						//***************
						if(k-j == tabuleiro*1){ //EXCLUINDO AS COLUNAS JXK
							goto fim;
						}
						if(l-j == tabuleiro*2){ //EXCLUINDO AS COLUNAS JXK
							goto fim;
						}
						//***************
						if(j-i == tabuleiro*1){ //EXCLUINDO AS COLUNAS IXJ
							goto fim;
						}
						if(k-i == tabuleiro*2){ //EXCLUINDO AS COLUNAS IXk
							goto fim;
						}
						if(l-i == tabuleiro*3){ //EXCLUINDO AS COLUNAS IXL
							goto fim;
						}
						printf("%d, %d, %d, %d\n", i, j, k, l);
						fim:
						printf("");
					}
				}
			}
		}*/
	}

	return 0;
}


